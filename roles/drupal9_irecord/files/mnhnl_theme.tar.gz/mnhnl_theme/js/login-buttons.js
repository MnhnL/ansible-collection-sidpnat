jQuery(document).ready(function($) {
  var list = $('.create-account-link').closest('ul');
  $(list).css('padding', '10px 0');
  $(list).find('li').css('list-style', 'none');
  $(list).find('li').css('display', 'inline-block');
  $(list).find('li').css('margin-right', '8px');
  $(list).find('a').addClass('btn btn-info');
});