jQuery(document).ready(function($) {
  // Ensure links in report grid or verification edits maintain the language path.
  if (typeof indiciaFns !== 'undefined' && window.location.pathname.match(/(\/mnhnl-dataportal)?\/(en|fr|de)\//)) {
    indiciaFns.on('click', '.report-grid a, #btn-edit-record', null, function (e) {
      var href = $(this).attr('href');
      var currentPath = window.location.pathname;
      if (currentPath.match(/^\/[a-z]{2}\//) && !href.match(/^http(s)?:\/\/biodiversiteit/)) {
        href = currentPath.substr(0, 3) + href;
        $(this).attr('href', href);
      }
    });
  }
});