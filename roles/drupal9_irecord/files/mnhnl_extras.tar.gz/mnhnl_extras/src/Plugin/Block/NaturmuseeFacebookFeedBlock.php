<?php

namespace Drupal\mnhnl_extras\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Component\Render\FormattableMarkup;

/**
 * Provides a Facebook Feed block.
 *
 * @Block(
 *   id = "naturmusee_facebook_feed_block",
 *   admin_label = @Translation("Naturmusee Facebook Feed block"),
 * )
 */
class NaturmuseeFacebookFeedBlock extends BlockBase {

  public function build() {
    $html = <<<HTML
<div class="fb-page" data-href="https://www.facebook.com/naturmuseelux/" data-tabs="timeline" data-width="500" data-adapt-container-width="true" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
  <blockquote cite="https://www.facebook.com/naturmuseelux/" class="fb-xfbml-parse-ignore">
    <a href="https://www.facebook.com/naturmuseelux/">Musée national d&#039;histoire naturelle Luxembourg - natur musée</a>
  </blockquote>
</div>
HTML;
    return [
      '#markup' => new FormattableMarkup($html, []),
    ];
  }

}
