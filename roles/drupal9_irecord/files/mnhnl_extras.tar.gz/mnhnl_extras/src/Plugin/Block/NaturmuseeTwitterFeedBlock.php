<?php

namespace Drupal\mnhnl_extras\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Component\Render\FormattableMarkup;

/**
 * Provides a Twitter Feed block.
 *
 * @Block(
 *   id = "naturmusee_twitter_feed_block",
 *   admin_label = @Translation("Naturmusee Twitter Feed block"),
 * )
 */
class NaturmuseeTwitterFeedBlock extends BlockBase {

  public function build() {

    /*$node = node_load(2);
    $languages = $node->getTranslationLanguages();
    $translations = array();
    foreach ($languages as $langcode => $language) {
      drupal_set_message("$langcode: " . $node->getTranslation($langcode)->isDefaultTranslation());
    }
    drupal_set_message('Language updated');*/

    /*$vids = \Drupal::entityManager()->getStorage('node')->revisionIds($node);
    foreach ($vids as $vid) {
      if ($vid !== 46) {
        \Drupal::entityTypeManager()->getStorage('node')->deleteRevision($vid);
        drupal_set_message("Deleted $vid");
      }
    }*/

    $html = <<<HTML

<a class="twitter-timeline"
  href="https://twitter.com/naturmusee"
  data-width="100%"
  data-height="550">
Tweets by @naturmusee
</a>

<script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));</script>
HTML;
    return [
      '#markup' => new FormattableMarkup($html, []),
    ];
  }

}
